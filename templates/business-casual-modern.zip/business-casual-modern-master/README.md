# business-casual

Template for a simple business 

Preview at https://bravecamp.github.io/business-casual/
