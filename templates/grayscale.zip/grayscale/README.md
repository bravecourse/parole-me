# grayscale
Template for single page website with space for large background images

Preview at https://bravecourse.github.io/grayscale/
