# stylish-portfolio

Template – one-page scroll; large description sections and bold colors

Preview at https://bravecourse.github.io/stylish-portfolio/
